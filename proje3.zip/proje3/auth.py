import streamlit as st
import pandas as pd
import os

USERS_FILE = "kullanicilar.csv"

def kullanicilari_yukle():
    if os.path.exists(USERS_FILE):
        try:
            # sep=',' ekleyerek virgülle ayrıldığını kesinleştiriyoruz
            df = pd.read_csv(USERS_FILE, sep=',')
            # Eğer Excel bozduysa ve tek sütun geldiyse temizlik yapalım
            if df.shape[1] == 1:
                st.error("CSV Dosyası bozuk görünüyor, lütfen kontrol et!")
            return df
        except Exception:
            return pd.DataFrame(columns=["kullanici_adi", "sifre"])
    return pd.DataFrame(columns=["kullanici_adi", "sifre"])

def kullanici_ekle(kadi, sifre):
    df = kullanicilari_yukle()
    if kadi in df["kullanici_adi"].values:
        return False
    yeni_user = pd.DataFrame([[kadi, sifre]], columns=["kullanici_adi", "sifre"])
    df = pd.concat([df, yeni_user], ignore_index=True)
    df.to_csv(USERS_FILE, index=False)
    return True

# Giriş kısmında da boşlukları temizleyelim (strip)
def giris_sayfasi():
    st.title("🔐 Dijital Beyin Güvenlik Geçidi")
    tab1, tab2 = st.tabs(["Giriş Yap", "Yeni Hesap Oluştur"])

    with tab1:
        k_adi = st.text_input("Kullanıcı Adı").strip() # Boşlukları siler
        sifre = st.text_input("Şifre", type="password").strip()
        
        if st.button("Sisteme Gir"):
            df = kullanicilari_yukle()
            # Hem kullanıcı adını hem şifreyi stringe çevirip kontrol ediyoruz
            match = df[(df["kullanici_adi"].astype(str) == k_adi) & 
                       (df["sifre"].astype(str) == sifre)]
            
            if not match.empty:
                st.session_state['logged_in'] = True
                st.session_state['user'] = k_adi
                st.rerun()
            else:
                st.error("Hatalı kullanıcı adı veya şifre!")

    with tab2:
        yeni_k = st.text_input("Yeni Kullanıcı Adı", key="r_user")
        yeni_s = st.text_input("Yeni Şifre", type="password", key="r_pass")
        if st.button("Hesap Oluştur"):
            if yeni_k and yeni_s:
                if kullanici_ekle(yeni_k, yeni_s):
                    st.success("Kayıt başarılı! Giriş yapabilirsiniz.")
                else:
                    st.error("Bu kullanıcı adı zaten alınmış!")