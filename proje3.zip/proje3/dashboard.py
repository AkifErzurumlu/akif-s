import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import os
import numpy as np

# --- 1. SENİN ORIJİNAL FORMÜLLERİN (data_generator.py) ---
def hesapla_uyku_puani(toplam_uyku_dk, derin_uyku_dk, uyanma_sayisi):
    puan = 50 + (toplam_uyku_dk / 10) * 0.5 + (derin_uyku_dk * 0.3) - (uyanma_sayisi * 3)
    return int(max(0, min(100, puan)))

def hesapla_stres_puani(ekran_suresi, uyku_puani):
    dijital_stres = ekran_suresi / 5
    uyku_yetersizligi_etkisi = (100 - uyku_puani) * 0.4
    hayat_faktoru = np.random.randint(-10, 15)
    return int(max(0, min(100, (dijital_stres + uyku_yetersizligi_etkisi + hayat_faktoru))))
def akilli_asistan_onerileri(df):
    st.markdown("---")
    st.subheader("💡 Dijital Sağlık Asistanı Önerileri")
    kullanici_adi = st.session_state.get('user', 'Kullanıcı')
    if df.empty:
        st.warning("Henüz öneri verecek kadar veri birikmedi")
        return
    # Son günün verilerini alalım
    son = df.sort_values('Tarih').iloc[-1]
    
    col1, col2 = st.columns([1, 2])
    with col1:
        st.info("📊 **Son Durum Analizi**")
        if son['Ekran_Suresi_Dk'] > 240: st.write("❌ Ekran süren limitin (4 saat) üzerinde.")
        if son['Uyku_Puani'] < 85: st.write("❌ Uyku kaliten 85 puanın altında.")
        if son['Stres_Puani'] > 50: st.write("❌ Stres seviyen 50'nin üzerinde.")
        if son['Ekran_Suresi_Dk'] <= 240 and son['Uyku_Puani'] >= 85:
            st.write("✅ Değerlerin gayet dengeli!")

    with col2:
        st.success("🎯 **Senin İçin Tavsiyeler**")
        # Senaryolara göre tavsiye ver
        if son['Ekran_Suresi_Dk'] > 240 and son['Stres_Puani'] > 50:
            st.warning(f"⚠️ **{kullanici_adi} Dikkat:** Bugün çok fazla ekrana bakmışsın ve stresin artmış. Hemen 20 dakika gözlerini kapatıp dinlenmelisin.")
        
        if son['Uyku_Puani'] < 85:
            st.info("🌙 **Uyku İpucu:** Uyku kaliteni artırmak için yatmadan önce odanı havalandır ve telefonunu başka odaya bırak.")
            
        if son['Stres_Puani'] > 50 and son['Ekran_Suresi_Dk'] <= 240:
            st.info("🧘 **Zihinsel Mola:** Ekran süren az olmasına rağmen stresin yüksek. Kısa bir yürüyüş veya nefes egzersizi iyi gelebilir.")

# Bunu analiz_sayfasi() içinde uygun bir yere (mesela grafiklerin altına) ekle:
# akilli_asistan_onerileri(df)

# --- 2. VERİ YÖNETİMİ ---
def kullanici_verisini_yukle(kullanici_adi):
    dosya_adi = f"veriler_{kullanici_adi}.csv"
    if os.path.exists(dosya_adi):
        df = pd.read_csv(dosya_adi)
        df['Tarih'] = pd.to_datetime(df['Tarih'], errors='coerce')
        df = df.dropna(subset=['Tarih'])
        return df
    else:
        # İlk kurulumda 30 günlük geçmiş üret
        dates = pd.date_range(end=pd.Timestamp.today(), periods=30)
        data = []
        for date in dates:
            screen_time = np.random.randint(120, 500)
            toplam_uyku = max(180, int(480 - (screen_time / 3) + np.random.randint(-30, 30)))
            derin_uyku = max(10, int((toplam_uyku * 0.20) - (screen_time / 20)))
            uyanma_sayisi = int((screen_time / 100) + np.random.randint(0, 3))
            s_puan = hesapla_uyku_puani(toplam_uyku, derin_uyku, uyanma_sayisi)
            st_puan = hesapla_stres_puani(screen_time, s_puan)
            data.append([date, screen_time, s_puan, st_puan, toplam_uyku, derin_uyku, uyanma_sayisi])
        
        df = pd.DataFrame(data, columns=['Tarih', 'Ekran_Suresi_Dk', 'Uyku_Puani', 'Stres_Puani', 'Toplam_Uyku_Dk', 'Derin_Uyku_Dk', 'Uyanma_Sayisi'])
        df.to_csv(dosya_adi, index=False)
        return df

def analiz_sayfasi():
    kullanici = st.session_state['user']
    dosya_adi = f"veriler_{kullanici}.csv"
    df = kullanici_verisini_yukle(kullanici)

    # --- SİDEBAR ---
    st.sidebar.markdown(f"### 👤 Kullanıcı: {kullanici}")
    
    with st.sidebar.expander("➕ Yeni Veri Ekle"):
        y_tarih = st.date_input("Tarih Seç", pd.Timestamp.today())
        y_ekran = st.number_input("Ekran Süresi (dk)", 0, 1000, 240)
        y_uyku = st.number_input("Toplam Uyku (dk)", 0, 1000, 480)
        y_derin = st.number_input("Derin Uyku (dk)", 0, 500, 90)
        y_uyanma = st.number_input("Uyanma Sayısı", 0, 10, 1)
        
        if st.button("Kaydet ve Güncelle"):
            # 1. Puanları hesapla
            s_puan = hesapla_uyku_puani(y_uyku, y_derin, y_uyanma)
            st_puan = hesapla_stres_puani(y_ekran, s_puan)
            
            # 2. Hata aldığın değişkeni burada tanımlıyoruz
            yeni_satir = pd.DataFrame([[
                y_tarih, y_ekran, s_puan, st_puan, y_uyku, y_derin, y_uyanma
            ]], columns=df.columns)
            
            # 3. Verileri birleştir ve aynı gün varsa en yenisini tut
            df = pd.concat([df, yeni_satir], ignore_index=True)
            df['Tarih'] = pd.to_datetime(df['Tarih']) # Tarih formatını garantiye al
            df = df.drop_duplicates('Tarih', keep='last')
            
            # 4. CSV dosyasına yaz
            df.to_csv(dosya_adi, index=False)
            
            # 5. Başarı mesajı göster ve sayfayı ZORLA yenile (Tablonun güncellenmesi için şart!)
            st.success("Veri başarıyla kaydedildi!")
            st.rerun()

    if st.sidebar.button("🚪 Güvenli Çıkış"):
        st.session_state['logged_in'] = False
        st.rerun()

    # --- ANA PANEL ---
    st.title("🧠 Dijital Beyin Analiz Paneli")
    
    # 1. Metrikler
    ref_ekran, ref_uyku, ref_stres = 240, 85, 50
    c1, c2, c3 = st.columns(3)
    o_ekran, o_uyku, o_stres = int(df['Ekran_Suresi_Dk'].mean()), int(df['Uyku_Puani'].mean()), int(df['Stres_Puani'].mean())
    
    c1.metric("Ort. Ekran", f"{o_ekran} dk", f"{o_ekran - ref_ekran} dk", delta_color="inverse")
    c2.metric("Uyku Puanı", f"{o_uyku}/100", f"{o_uyku - ref_uyku}")
    c3.metric("Ort. Stres", f"{o_stres}/100", f"{o_stres - ref_stres}", delta_color="inverse")
    akilli_asistan_onerileri(df)

    # 2. Haftalık Gelişim Grafiği (Line Chart)
    st.markdown("---")
    st.subheader("📈 Zaman İçindeki Değişim")
    df_sorted = df.sort_values('Tarih')
    
    fig_line = go.Figure()
    fig_line.add_trace(go.Scatter(x=df_sorted['Tarih'], y=df_sorted['Uyku_Puani'], name="Uyku Puanı", line=dict(color='royalblue', width=3)))
    fig_line.add_trace(go.Scatter(x=df_sorted['Tarih'], y=df_sorted['Stres_Puani'], name="Stres Puanı", line=dict(color='firebrick', width=3)))
    fig_line.update_layout(title="Uyku ve Stres Dengesi (Son 30 Gün)", xaxis_title="Tarih", yaxis_title="Puan")
    st.plotly_chart(fig_line, use_container_width=True)

    # 3. Orijinal Dağılım Grafiği (Scatter)
    st.markdown("---")
    st.subheader("📉 Ekran - Uyku - Stres İlişkisi")
    fig_scatter = px.scatter(df, x="Ekran_Suresi_Dk", y="Uyku_Puani", color="Stres_Puani", size="Stres_Puani",
                             color_continuous_scale="RdBu_r", trendline="ols",
                             hover_data=['Toplam_Uyku_Dk', 'Uyanma_Sayisi'])
    fig_scatter.add_vline(x=ref_ekran, line_dash="dash", line_color="green")
    fig_scatter.add_hline(y=ref_uyku, line_dash="dash", line_color="green")
    st.plotly_chart(fig_scatter, use_container_width=True)

    with st.expander("📑 Tüm Veri Kayıtları"):
        st.dataframe(df.sort_values('Tarih', ascending=False))