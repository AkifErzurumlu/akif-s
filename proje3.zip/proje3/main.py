import streamlit as st
import auth
import dashboard

# 1. SAYFA KONFİGÜRASYONU
st.set_page_config(page_title="Dijital Sağlık", page_icon="📱", layout="wide")

# 2. OTURUM DURUMU BAŞLATMA
if 'logged_in' not in st.session_state:
    st.session_state['logged_in'] = False
if 'user' not in st.session_state:
    st.session_state['user'] = ""

# 3. YÖNLENDİRME MANTIĞI
if st.session_state['logged_in']:
    dashboard.analiz_sayfasi()
else:
    auth.giris_sayfasi()